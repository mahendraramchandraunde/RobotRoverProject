using NUnit.Framework;
using System.Collections.Generic;
using Robot_Rover;

namespace Robot_Rover_UnitTest
{
    public class When_Moving_Rover
    {
        
        [Test]
        public void Valid_Command_Sequence_Movement_Is_Successful()
        {
            Rover_SetPosition position = new Rover_SetPosition()
            {
                X = 10,
                Y = 10,
                Direction = Directions.N
            };
            
            var moves = "R1R3L2L1";

            position.Move(moves);

            var actualOutput = $"{position.X} {position.Y} {position.Direction.ToString()}";
            var expectedOutput = "13 8 N";

            Assert.AreEqual(expectedOutput, actualOutput);
        }
                       

        [Test]
        public void Impermissible_Command_Sequence_Causes_Fall_Off_Plateau()
        {
            Rover_SetPosition position = new Rover_SetPosition()
            {
                X = 10,
                Y = 10,
                Direction = Directions.N
            };

            var moves = "R1R3L2L1 N";

            position.Move(moves);

            var actualOutput = $"{position.X} {position.Y} {position.Direction.ToString()}";
            var expectedOutput = "13 8 N";

            Assert.AreEqual(expectedOutput, actualOutput);
        }
    }
}