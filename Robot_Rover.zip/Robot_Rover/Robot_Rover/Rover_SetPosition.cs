﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Robot_Rover
{

    public enum Directions
    {
        N = 1,//North
        S = 2,//South
        E = 3,//East
        W = 4//West
    }

    public interface IMove
    {
        void Move(string moves);
    }
    public class Rover_SetPosition :IMove
    {
        public int X { get; set; }
        public int Y { get; set; }
        public Directions Direction { get; set; }

        public Rover_SetPosition()
        {
            X = Y = 0;
            Direction = Directions.N;
        }

        private void Rotate90Left()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.W;
                    break;
                case Directions.S:
                    this.Direction = Directions.E;
                    break;
                case Directions.E:
                    this.Direction = Directions.N;
                    break;
                case Directions.W:
                    this.Direction = Directions.S;
                    break;
                default:
                    throw new ArgumentException();
            }
        }

        private void Rotate90Right()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.E;
                    break;
                case Directions.S:
                    this.Direction = Directions.W;
                    break;
                case Directions.E:
                    this.Direction = Directions.S;
                    break;
                case Directions.W:
                    this.Direction = Directions.N;
                    break;
                default:
                    throw new ArgumentException();
            }
        }

        private void PositionToMove(int NumberToMove)
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Y += NumberToMove;
                    break;
                case Directions.S:
                    this.Y -= NumberToMove;
                    break;
                case Directions.E:
                    this.X += NumberToMove;
                    break;
                case Directions.W:
                    this.X -= NumberToMove;
                    break;
                default:
                    throw new ArgumentException();
            }
        }


        public void Move(string moves)
        {
            foreach (var move in moves)
            {
                bool result;              
                result = Char.IsNumber(move.ToString(), 0);
                if (result==true)
                {
                    this.PositionToMove(Convert.ToInt32(move.ToString()));
                }
                else
                {
                    switch (move)
                    {                        
                        case 'L':
                            this.Rotate90Left();
                            break;
                        case 'R':
                            this.Rotate90Right();
                            break;
                        default:
                            Console.WriteLine($"Invalid command {move}. Valid commands are any number or L, R or combination of this. L='Left', R='Right'.");
                            throw new ArgumentException();
                    }

                }
                              
            }
        }

    }
}
