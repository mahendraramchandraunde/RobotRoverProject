﻿using System;
using System.Linq;

namespace Robot_Rover
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter a valid command :");//uncomment this to allow user input
            //var startPositions = Console.ReadLine().Trim().Split(' ');//uncomment this to allow user input
            Console.WriteLine("Default Position is set as 10 10 N :");//comment/remove this to allow user input
            string HardCodedCommandPosition = "10 10 N";//comment/remove this to allow user input
            var startPositions = HardCodedCommandPosition.ToString().Trim().Split(' ');//comment/remove this to allow user input
            Rover_SetPosition position = new Rover_SetPosition();

            if (startPositions.Count() == 3)
            {
                position.X = Convert.ToInt32(startPositions[0]);
                position.Y = Convert.ToInt32(startPositions[1]);
                position.Direction = (Directions)Enum.Parse(typeof(Directions), startPositions[2]);

                //Console.WriteLine("Enter the command to Move (L or M or R) :");//uncomment this to allow user input
                //var moves = Console.ReadLine().ToUpper();//uncomment this to allow user input
                Console.WriteLine("Default command is set as R1R3L2L1 :");//comment/remove this to allow user input
                string HardCodedCommandMoves = "R1R3L2L1";//comment/remove this to allow user input
                var moves = HardCodedCommandMoves.ToUpper();//comment/remove this to allow user input

                try
                {
                    position.Move(moves);
                    Console.WriteLine($"{position.X} {position.Y} {position.Direction.ToString()}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            Console.ReadLine();
        }
    }
}
